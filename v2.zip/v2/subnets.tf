#######################################
#     1. EKS PRIVATE SUBNETS
#######################################
resource "aws_subnet" "eks_subnets" {
  count                   = length(var.eks_subnet_cidrs)
  vpc_id                  = var.vpc_id
  cidr_block              = var.eks_subnet_cidrs[count.index]
  availability_zone       = var.azs[count.index]
  map_public_ip_on_launch = false

  tags = merge(var.common_tags, {
    Name = "eks-subnet-${count.index}"
    Type = "eks"
  })
}

#######################################
#     2. EFS PRIVATE SUBNETS
#######################################
resource "aws_subnet" "efs_subnets" {
  count                   = length(var.efs_subnet_cidrs)
  vpc_id                  = var.vpc_id
  cidr_block              = var.efs_subnet_cidrs[count.index]
  availability_zone       = var.azs[count.index]
  map_public_ip_on_launch = false

  tags = merge(var.common_tags, {
    Name = "efs-subnet-${count.index}"
    Type = "efs"
  })
}


#######################################
#     3. PUBLIC SUBNETS
#######################################

resource "aws_subnet" "public_subnets" {
  count                   = length(var.public_subnet_cidrs)
  vpc_id                  = var.vpc_id
  cidr_block              = var.public_subnet_cidrs[count.index]
  availability_zone       = var.azs[count.index]
  map_public_ip_on_launch = true

  tags = merge(var.common_tags, {
    Name = "public-subnet-${count.index}"
    Type = "public"
  })
}