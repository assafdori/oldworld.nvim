#######################################
#  CODECOMMIT REPOSITORY
#######################################
resource "aws_codecommit_repository" "repo" {
  repository_name = "eks-terraform-infra"
  description     = "Repository for EKS Terraform infrastructure"
}

#######################################
#  CODEBUILD ROLE & POLICY
#######################################
resource "aws_iam_role" "codebuild_role" {
  name = "eks-terraform-codebuild-role"
  assume_role_policy = jsonencode({
    Version   = "2012-10-17",
    Statement = [{
      Effect    = "Allow",
      Principal = { Service = "codebuild.amazonaws.com" },
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_policy" "codebuild_policy" {
  name = "eks-terraform-codebuild-policy"
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect   = "Allow",
        Action   = [
          "codecommit:GitPull",
          "s3:*",
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents",
          "sts:AssumeRole"
        ],
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "codebuild_policy_attach" {
  role       = aws_iam_role.codebuild_role.name
  policy_arn = aws_iam_policy.codebuild_policy.arn
}

#######################################
#  CODEBUILD PROJECT
#######################################
resource "aws_codebuild_project" "build" {
  name          = "eks-terraform-build"
  description   = "Build project for deploying EKS Terraform infrastructure"
  service_role  = aws_iam_role.codebuild_role.arn

  artifacts {
    type = "NO_ARTIFACTS"
  }

  environment {
    compute_type    = "BUILD_GENERAL1_SMALL"
    image           = "aws/codebuild/standard:6.0"
    type            = "LINUX_CONTAINER"
    privileged_mode = true
  }

  source {
    type      = "CODECOMMIT"
    location  = aws_codecommit_repository.repo.clone_url_http
    buildspec = file("buildspec.yml")
  }
}

#######################################
#  CODEPIPELINE ROLE & POLICY
#######################################
resource "aws_iam_role" "codepipeline_role" {
  name = "eks-terraform-codepipeline-role"
  assume_role_policy = jsonencode({
    Version   = "2012-10-17",
    Statement = [{
      Effect    = "Allow",
      Principal = { Service = "codepipeline.amazonaws.com" },
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_policy" "codepipeline_policy" {
  name = "eks-terraform-codepipeline-policy"
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "s3:*",
          "codecommit:*",
          "codebuild:*"
        ],
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "codepipeline_policy_attach" {
  role       = aws_iam_role.codepipeline_role.name
  policy_arn = aws_iam_policy.codepipeline_policy.arn
}

#######################################
#  S3 BUCKET FOR CODEPIPELINE ARTIFACTS
#######################################
resource "random_id" "bucket_id" {
  byte_length = 4
}

resource "aws_s3_bucket" "codepipeline_bucket" {
  bucket        = "eks-terraform-codepipeline-bucket-${random_id.bucket_id.hex}"
  force_destroy = true
}

#######################################
#  CODEPIPELINE
#######################################
resource "aws_codepipeline" "pipeline" {
  name     = "eks-terraform-pipeline"
  role_arn = aws_iam_role.codepipeline_role.arn

  artifact_store {
    type     = "S3"
    location = aws_s3_bucket.codepipeline_bucket.bucket
  }

  stage {
    name = "Source"
    action {
      name             = "Source"
      category         = "Source"
      owner            = "AWS"
      provider         = "CodeCommit"
      version          = "1"
      output_artifacts = ["SourceArtifact"]
      configuration = {
        RepositoryName = aws_codecommit_repository.repo.repository_name
        BranchName     = "main"
      }
    }
  }

  stage {
    name = "Build"
    action {
      name             = "Build"
      category         = "Build"
      owner            = "AWS"
      provider         = "CodeBuild"
      input_artifacts  = ["SourceArtifact"]
      output_artifacts = ["BuildArtifact"]
      version = "1"
      configuration = {
        ProjectName = aws_codebuild_project.build.name
      }
    }
  }
}
