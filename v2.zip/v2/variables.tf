#########################################################
#                    MAIN VARIABLES
#########################################################
variable "aws_region" {
  type        = string
  description = "AWS region."
  default     = "il-central-1"
}

variable "vpc_id" {
  type        = string
  description = "ID of an existing VPC in which to create subnets"
}

variable "azs" {
  type        = list(string)
  description = "List of availability zones to use"
  default     = ["il-central-1a", "il-central-1b", "il-central-1c"]
}

#########################################################
#                  CIDR BLOCK VARIABLES
#########################################################
variable "eks_subnet_cidrs" {
  type        = list(string)
  description = "CIDRs for EKS private subnets"
  default     = ["10.0.4.0/22", "10.0.8.0/22", "10.0.12.0/22"]
}

variable "efs_subnet_cidrs" {
  type        = list(string)
  description = "CIDRs for EFS private subnets"
  default     = ["10.0.16.0/28", "10.0.16.16/28", "10.0.16.32/28"]
}

variable "tgw_subnet_cidrs" {
  type        = list(string)
  description = "CIDRs for TGW private subnets"
  default     = ["10.0.16.48/28", "10.0.16.64/28", "10.0.16.80/28"]
}

variable "public_subnet_cidrs" {
  type        = list(string)
  description = "CIDRs for public subnets"
  default     = ["10.0.0.0/24"]
}

#########################################################
#                 EKS & CLUSTER VARIABLES
#########################################################
variable "eks_cluster_name" {
  type        = string
  description = "Name of the EKS cluster"
  default     = "moj-quali-eks-cluster"
}

variable "eks_version" {
  type        = string
  description = "Kubernetes version for EKS (e.g., 1.25, 1.26)"
  default     = "1.31"
}

variable "enable_public_endpoint" {
  type        = bool
  description = "Whether to enable public endpoint for EKS"
  default     = true
}

variable "public_access_cidrs" {
  type        = list(string)
  description = "List of CIDRs allowed to access the public EKS endpoint"
  default     = ["0.0.0.0/0"] # put torque public IPs here
}

variable "instance_type" {
  type        = string
  description = "Instance type for EKS worker nodes (4 vCPU, 16GB ~ xlarge)"
  default     = "m5.xlarge"
}

variable "desired_capacity" {
  type        = number
  description = "Desired number of EKS nodes"
  default     = 3
}

variable "max_capacity" {
  type        = number
  description = "Max number of EKS nodes"
  default     = 10
}

#########################################################
#                     EFS VARIABLES
#########################################################
variable "efs_name" {
  type        = string
  description = "Name for the EFS file system"
  default     = "cluster-efs"
}

#########################################################
#                       TAGGING
#########################################################
variable "common_tags" {
  type        = map(string)
  description = "Common tags applied to all resources"
  default = {
    Environment = "Dev"
    Project     = "Example"
  }
}
