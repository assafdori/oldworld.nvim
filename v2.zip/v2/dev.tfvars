# terraform.tfvars

aws_region = "il-central-1"

# The existing VPC ID
vpc_id = "vpc-053857e8dd9a1bf67"

# Availability zones in il-central-1
azs = [
  "il-central-1a",
  "il-central-1b",
  "il-central-1c"
]

# EKS /22 subnets
eks_subnet_cidrs = [
  "10.0.4.0/22",
  "10.0.8.0/22",
  "10.0.12.0/22"
]

# EFS /28 subnets
efs_subnet_cidrs = [
  "10.0.16.0/28",
  "10.0.16.16/28",
  "10.0.16.32/28"
]

# EKS cluster info
eks_cluster_name       = "eks-torque"
eks_version            = "1.31"
enable_public_endpoint = false
public_access_cidrs    = ["10.10.0.0/16"] # put torque ip here

# EFS name
efs_name = "torque-eks-efs"

# Common tags
common_tags = {
  Environment = "Dev"
  Project     = "Torque"
  Owner       = "Terraform"
}