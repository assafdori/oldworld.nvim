#########################################################
#        TRANSIT GATEWAY ATTACHMENT (OPTIONAL)
#########################################################
#variable "tgw_id" {
#  type        = string
#  description = "ID of the existing Transit Gateway"
#  default     = ""
#}

#resource "aws_ec2_transit_gateway_vpc_attachment" "this" {
#  transit_gateway_id = var.tgw_id
#  vpc_id             = var.vpc_id
#  subnet_ids         = [for s in aws_subnet.tgw_subnets : s.id]
#
#  tags = merge(var.common_tags, { Name = "my-tgw-attachment" })
#}