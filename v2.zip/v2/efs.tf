resource "aws_efs_file_system" "this" {
  creation_token = var.efs_name
  tags = merge(var.common_tags, {
    Name = var.efs_name
  })
}

# EFS security group: allow inbound NFS from EKS nodes
resource "aws_security_group" "efs_sg" {
  name        = "efs-sg"
  description = "Allow NFS from EKS node group"
  vpc_id      = var.vpc_id

  ingress {
    protocol  = "tcp"
    from_port = 2049
    to_port   = 2049
    security_groups = [aws_eks_cluster.this.vpc_config[0].cluster_security_group_id]
    description = "Allow NFS from EKS worker nodes"
  }

  depends_on = [aws_eks_cluster.this]

  egress {
    protocol    = "-1"
    from_port   = 0
    to_port     = 0
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(var.common_tags, { Name = "efs-sg" })
}

# EFS Mount Targets in EFS subnets
resource "aws_efs_mount_target" "efs_mt" {
  count           = length(var.efs_subnet_cidrs)
  file_system_id  = aws_efs_file_system.this.id
  subnet_id       = aws_subnet.efs_subnets[count.index].id
  security_groups = [aws_security_group.efs_sg.id]

  depends_on = [aws_efs_file_system.this]
}
