#########################################################
#                     OUTPUTS
#########################################################
output "eks_cluster_id" {
  value = aws_eks_cluster.this.id
}

output "eks_cluster_endpoint" {
  value = aws_eks_cluster.this.endpoint
}

output "efs_file_system_id" {
  value = aws_efs_file_system.this.id
}

output "efs_mount_targets" {
  value = [for mt in aws_efs_mount_target.efs_mt : mt.id]
}

output "eks_subnets" {
  value = [for s in aws_subnet.eks_subnets : s.id]
}