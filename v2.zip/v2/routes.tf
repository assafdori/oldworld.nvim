#########################################################
#  3. NAT GATEWAYS (ONE PER PUBLIC SUBNET FOR HA)
#########################################################
resource "aws_eip" "nat" {
  count = length(var.public_subnet_cidrs)
  tags  = merge(var.common_tags, { Name = "nat-eip-${count.index}" })
}

resource "aws_nat_gateway" "nat_gw" {
  count         = length(var.public_subnet_cidrs)
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public_subnets[count.index].id

  tags = merge(var.common_tags, { Name = "nat-gateway-${count.index}" })
}

#########################################################
#  4. EKS PRIVATE SUBNET ROUTES
#########################################################
resource "aws_route_table" "eks_rt" {
  count = length(var.eks_subnet_cidrs)
  vpc_id = var.vpc_id

  tags = merge(var.common_tags, {
    Name = "eks-private-rt-${count.index}"
  })
}

# Route EKS private subnets to NAT gateway in the same AZ
resource "aws_route" "eks_private_route" {
  count                  = length(var.eks_subnet_cidrs)
  route_table_id         = aws_route_table.eks_rt[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = aws_nat_gateway.nat_gw[0].id
}

resource "aws_route_table_association" "eks_rt_association" {
  count          = length(var.eks_subnet_cidrs)
  subnet_id      = aws_subnet.eks_subnets[count.index].id
  route_table_id = aws_route_table.eks_rt[count.index].id
}

#########################################################
#  5. EFS PRIVATE SUBNET ROUTES
#########################################################
resource "aws_route_table" "efs_rt" {
  count = length(var.efs_subnet_cidrs)
  vpc_id = var.vpc_id

  tags = merge(var.common_tags, {
    Name = "efs-private-rt-${count.index}"
  })
}

# Route EFS private subnets to NAT gateway in the same AZ (if needed)
resource "aws_route" "efs_private_route" {
  count                  = length(var.efs_subnet_cidrs)
  route_table_id         = aws_route_table.efs_rt[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = aws_nat_gateway.nat_gw[0].id
}

resource "aws_route_table_association" "efs_rt_association" {
  count          = length(var.efs_subnet_cidrs)
  subnet_id      = aws_subnet.efs_subnets[count.index].id
  route_table_id = aws_route_table.efs_rt[count.index].id
}