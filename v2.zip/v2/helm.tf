resource "helm_release" "efs_csi" {
  name       = "aws-efs-csi-driver"
  repository = "https://kubernetes-sigs.github.io/aws-efs-csi-driver/" # TODO: CHANGE TO HARBOR REPO
  chart      = "aws-efs-csi-driver"
  version    = "2.3.6"
  namespace  = "kube-system"
}